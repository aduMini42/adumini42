--
-- PostgreSQL database dump
--

\restrict jMNGPAdnC6rXRnrvYsXI1ZWXlgcqVOB0ZwEF4JkyKhaRtAshlIMI9aw0g2kEUD2

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cpen208; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA cpen208;


ALTER SCHEMA cpen208 OWNER TO postgres;

--
-- Name: get_outstanding_fees(); Type: FUNCTION; Schema: cpen208; Owner: postgres
--

CREATE FUNCTION cpen208.get_outstanding_fees() RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
BEGIN
  RETURN COALESCE((
    SELECT jsonb_agg(
      jsonb_build_object(
        'student_id', x.student_id,
        'student_name', x.full_name,
        'amount_due', x.amount_due,
        'amount_paid', x.amount_paid,
        'outstanding', GREATEST(x.amount_due - x.amount_paid, 0)
      ) ORDER BY x.full_name
    )
    FROM (
      SELECT s.student_id, s.full_name,
             COALESCE(SUM(fi.amount_due),0) AS amount_due,
             COALESCE(SUM(fp.paid),0) AS amount_paid
      FROM students s
      LEFT JOIN fee_invoices fi ON fi.student_id = s.student_id
      LEFT JOIN (
        SELECT invoice_id, SUM(amount_paid) AS paid
        FROM fee_payments GROUP BY invoice_id
      ) fp ON fp.invoice_id = fi.invoice_id
      GROUP BY s.student_id, s.full_name
    ) x
  ), '[]'::jsonb);
END;
$$;


ALTER FUNCTION cpen208.get_outstanding_fees() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_users; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.app_users (
    user_id bigint NOT NULL,
    name character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE cpen208.app_users OWNER TO postgres;

--
-- Name: app_users_user_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.app_users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.app_users_user_id_seq OWNER TO postgres;

--
-- Name: app_users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.app_users_user_id_seq OWNED BY cpen208.app_users.user_id;


--
-- Name: course_enrollments; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.course_enrollments (
    enrollment_id bigint NOT NULL,
    student_id character varying(20) NOT NULL,
    course_id character varying(20) NOT NULL,
    enrolled_on date DEFAULT CURRENT_DATE NOT NULL,
    status character varying(20) DEFAULT 'Enrolled'::character varying NOT NULL,
    CONSTRAINT course_enrollments_status_check CHECK (((status)::text = ANY ((ARRAY['Enrolled'::character varying, 'Dropped'::character varying, 'Completed'::character varying])::text[])))
);


ALTER TABLE cpen208.course_enrollments OWNER TO postgres;

--
-- Name: course_enrollments_enrollment_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.course_enrollments_enrollment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.course_enrollments_enrollment_id_seq OWNER TO postgres;

--
-- Name: course_enrollments_enrollment_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.course_enrollments_enrollment_id_seq OWNED BY cpen208.course_enrollments.enrollment_id;


--
-- Name: course_lecturers; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.course_lecturers (
    assignment_id bigint NOT NULL,
    course_id character varying(20) NOT NULL,
    lecturer_id integer NOT NULL,
    assigned_on date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE cpen208.course_lecturers OWNER TO postgres;

--
-- Name: course_lecturers_assignment_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.course_lecturers_assignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.course_lecturers_assignment_id_seq OWNER TO postgres;

--
-- Name: course_lecturers_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.course_lecturers_assignment_id_seq OWNED BY cpen208.course_lecturers.assignment_id;


--
-- Name: course_tas; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.course_tas (
    assignment_id bigint NOT NULL,
    course_id character varying(20) NOT NULL,
    ta_id integer NOT NULL,
    assigned_on date DEFAULT CURRENT_DATE NOT NULL
);


ALTER TABLE cpen208.course_tas OWNER TO postgres;

--
-- Name: course_tas_assignment_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.course_tas_assignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.course_tas_assignment_id_seq OWNER TO postgres;

--
-- Name: course_tas_assignment_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.course_tas_assignment_id_seq OWNED BY cpen208.course_tas.assignment_id;


--
-- Name: courses; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.courses (
    course_id character varying(20) NOT NULL,
    course_name character varying(150) NOT NULL,
    credit_hours integer NOT NULL,
    semester character varying(30) NOT NULL,
    academic_year character varying(20) NOT NULL,
    CONSTRAINT courses_credit_hours_check CHECK ((credit_hours > 0))
);


ALTER TABLE cpen208.courses OWNER TO postgres;

--
-- Name: fee_invoices; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.fee_invoices (
    invoice_id bigint NOT NULL,
    student_id character varying(20) NOT NULL,
    academic_year character varying(20) NOT NULL,
    semester character varying(30) NOT NULL,
    amount_due numeric(12,2) NOT NULL,
    due_date date NOT NULL,
    CONSTRAINT fee_invoices_amount_due_check CHECK ((amount_due >= (0)::numeric))
);


ALTER TABLE cpen208.fee_invoices OWNER TO postgres;

--
-- Name: fee_invoices_invoice_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.fee_invoices_invoice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.fee_invoices_invoice_id_seq OWNER TO postgres;

--
-- Name: fee_invoices_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.fee_invoices_invoice_id_seq OWNED BY cpen208.fee_invoices.invoice_id;


--
-- Name: fee_payments; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.fee_payments (
    payment_id bigint NOT NULL,
    student_id character varying(20) NOT NULL,
    invoice_id bigint NOT NULL,
    amount_paid numeric(12,2) NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    reference character varying(60) NOT NULL,
    CONSTRAINT fee_payments_amount_paid_check CHECK ((amount_paid > (0)::numeric))
);


ALTER TABLE cpen208.fee_payments OWNER TO postgres;

--
-- Name: fee_payments_payment_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.fee_payments_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.fee_payments_payment_id_seq OWNER TO postgres;

--
-- Name: fee_payments_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.fee_payments_payment_id_seq OWNED BY cpen208.fee_payments.payment_id;


--
-- Name: lecturers; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.lecturers (
    lecturer_id integer NOT NULL,
    full_name character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    department character varying(120) DEFAULT 'Computer Engineering'::character varying NOT NULL
);


ALTER TABLE cpen208.lecturers OWNER TO postgres;

--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.lecturers_lecturer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.lecturers_lecturer_id_seq OWNER TO postgres;

--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.lecturers_lecturer_id_seq OWNED BY cpen208.lecturers.lecturer_id;


--
-- Name: students; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.students (
    student_id character varying(20) NOT NULL,
    full_name character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    department character varying(120) DEFAULT 'Computer Engineering'::character varying NOT NULL,
    account_status character varying(20) DEFAULT 'Active'::character varying NOT NULL,
    CONSTRAINT students_account_status_check CHECK (((account_status)::text = ANY ((ARRAY['Active'::character varying, 'Inactive'::character varying])::text[])))
);


ALTER TABLE cpen208.students OWNER TO postgres;

--
-- Name: student_fee_summary; Type: VIEW; Schema: cpen208; Owner: postgres
--

CREATE VIEW cpen208.student_fee_summary AS
 SELECT s.student_id,
    s.full_name,
    COALESCE(sum(fi.amount_due), (0)::numeric) AS total_due,
    COALESCE(sum(p.paid), (0)::numeric) AS total_paid,
    GREATEST((COALESCE(sum(fi.amount_due), (0)::numeric) - COALESCE(sum(p.paid), (0)::numeric)), (0)::numeric) AS outstanding
   FROM ((cpen208.students s
     LEFT JOIN cpen208.fee_invoices fi ON (((fi.student_id)::text = (s.student_id)::text)))
     LEFT JOIN ( SELECT fee_payments.invoice_id,
            sum(fee_payments.amount_paid) AS paid
           FROM cpen208.fee_payments
          GROUP BY fee_payments.invoice_id) p ON ((p.invoice_id = fi.invoice_id)))
  GROUP BY s.student_id, s.full_name;


ALTER VIEW cpen208.student_fee_summary OWNER TO postgres;

--
-- Name: teaching_assistants; Type: TABLE; Schema: cpen208; Owner: postgres
--

CREATE TABLE cpen208.teaching_assistants (
    ta_id integer NOT NULL,
    student_id character varying(20) NOT NULL,
    role character varying(30) DEFAULT 'TA'::character varying NOT NULL
);


ALTER TABLE cpen208.teaching_assistants OWNER TO postgres;

--
-- Name: teaching_assistants_ta_id_seq; Type: SEQUENCE; Schema: cpen208; Owner: postgres
--

CREATE SEQUENCE cpen208.teaching_assistants_ta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE cpen208.teaching_assistants_ta_id_seq OWNER TO postgres;

--
-- Name: teaching_assistants_ta_id_seq; Type: SEQUENCE OWNED BY; Schema: cpen208; Owner: postgres
--

ALTER SEQUENCE cpen208.teaching_assistants_ta_id_seq OWNED BY cpen208.teaching_assistants.ta_id;


--
-- Name: app_users user_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.app_users ALTER COLUMN user_id SET DEFAULT nextval('cpen208.app_users_user_id_seq'::regclass);


--
-- Name: course_enrollments enrollment_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_enrollments ALTER COLUMN enrollment_id SET DEFAULT nextval('cpen208.course_enrollments_enrollment_id_seq'::regclass);


--
-- Name: course_lecturers assignment_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_lecturers ALTER COLUMN assignment_id SET DEFAULT nextval('cpen208.course_lecturers_assignment_id_seq'::regclass);


--
-- Name: course_tas assignment_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_tas ALTER COLUMN assignment_id SET DEFAULT nextval('cpen208.course_tas_assignment_id_seq'::regclass);


--
-- Name: fee_invoices invoice_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_invoices ALTER COLUMN invoice_id SET DEFAULT nextval('cpen208.fee_invoices_invoice_id_seq'::regclass);


--
-- Name: fee_payments payment_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_payments ALTER COLUMN payment_id SET DEFAULT nextval('cpen208.fee_payments_payment_id_seq'::regclass);


--
-- Name: lecturers lecturer_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.lecturers ALTER COLUMN lecturer_id SET DEFAULT nextval('cpen208.lecturers_lecturer_id_seq'::regclass);


--
-- Name: teaching_assistants ta_id; Type: DEFAULT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.teaching_assistants ALTER COLUMN ta_id SET DEFAULT nextval('cpen208.teaching_assistants_ta_id_seq'::regclass);


--
-- Data for Name: app_users; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.app_users (user_id, name, email, password_hash, created_at) FROM stdin;
1	Joni Mitchell	jonimitchell@st.ug.edu.gh	$2a$12$HoUZDOC8.Sk888KDS.pmheaSMaVFjDLfQ770nNHOaBKFmvkVi4aF6	2026-08-14 10:24:36.919017+01
2	Hellen	hellen@gmail.com	$2a$12$IpT/IgWSflfBDXPFk0JJYeB3fkPDCdsbueWJY8TYOxp.Vl1NRH0O6	2026-08-14 17:16:53.612388+01
\.


--
-- Data for Name: course_enrollments; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.course_enrollments (enrollment_id, student_id, course_id, enrolled_on, status) FROM stdin;
181	87654321	CPEN208	2026-08-14	Enrolled
71	22384451	CPEN208	2026-08-14	Enrolled
72	22357814	CPEN208	2026-08-14	Enrolled
73	22375367	CPEN208	2026-08-14	Enrolled
74	22397756	CPEN208	2026-08-14	Enrolled
75	22369321	CPEN208	2026-08-14	Enrolled
76	22301848	CPEN208	2026-08-14	Enrolled
77	22339520	CPEN208	2026-08-14	Enrolled
78	22333597	CPEN208	2026-08-14	Enrolled
79	22268986	CPEN208	2026-08-14	Enrolled
80	22381577	CPEN208	2026-08-14	Enrolled
81	22315830	CPEN208	2026-08-14	Enrolled
82	22388189	CPEN208	2026-08-14	Enrolled
83	22393520	CPEN208	2026-08-14	Enrolled
84	22312110	CPEN208	2026-08-14	Enrolled
85	22300896	CPEN208	2026-08-14	Enrolled
86	22397491	CPEN208	2026-08-14	Enrolled
87	22387715	CPEN208	2026-08-14	Enrolled
88	22382302	CPEN208	2026-08-14	Enrolled
89	22379061	CPEN208	2026-08-14	Enrolled
90	22368809	CPEN208	2026-08-14	Enrolled
91	22370498	CPEN208	2026-08-14	Enrolled
92	22382425	CPEN208	2026-08-14	Enrolled
93	22396551	CPEN208	2026-08-14	Enrolled
94	22398562	CPEN208	2026-08-14	Enrolled
95	22398596	CPEN208	2026-08-14	Enrolled
96	22385323	CPEN208	2026-08-14	Enrolled
97	22303421	CPEN208	2026-08-14	Enrolled
98	22407033	CPEN208	2026-08-14	Enrolled
99	22299189	CPEN208	2026-08-14	Enrolled
100	22407837	CPEN208	2026-08-14	Enrolled
101	22412615	CPEN208	2026-08-14	Enrolled
102	22411009	CPEN208	2026-08-14	Enrolled
103	22382547	CPEN208	2026-08-14	Enrolled
104	22373317	CPEN208	2026-08-14	Enrolled
105	22339058	CPEN208	2026-08-14	Enrolled
106	22302628	CPEN208	2026-08-14	Enrolled
107	22396566	CPEN208	2026-08-14	Enrolled
108	22325819	CPEN208	2026-08-14	Enrolled
109	22344703	CPEN208	2026-08-14	Enrolled
110	22306910	CPEN208	2026-08-14	Enrolled
111	22385472	CPEN208	2026-08-14	Enrolled
112	22399214	CPEN208	2026-08-14	Enrolled
113	22263126	CPEN208	2026-08-14	Enrolled
114	22373463	CPEN208	2026-08-14	Enrolled
115	22381702	CPEN208	2026-08-14	Enrolled
116	22387846	CPEN208	2026-08-14	Enrolled
117	22263922	CPEN208	2026-08-14	Enrolled
118	22401641	CPEN208	2026-08-14	Enrolled
119	22403781	CPEN208	2026-08-14	Enrolled
120	22304260	CPEN208	2026-08-14	Enrolled
121	22304013	CPEN208	2026-08-14	Enrolled
122	22302188	CPEN208	2026-08-14	Enrolled
123	22299949	CPEN208	2026-08-14	Enrolled
124	22415339	CPEN208	2026-08-14	Enrolled
125	22328334	CPEN208	2026-08-14	Enrolled
126	22412982	CPEN208	2026-08-14	Enrolled
127	22321110	CPEN208	2026-08-14	Enrolled
128	22306021	CPEN208	2026-08-14	Enrolled
129	22385391	CPEN208	2026-08-14	Enrolled
130	22394866	CPEN208	2026-08-14	Enrolled
131	22382601	CPEN208	2026-08-14	Enrolled
132	22271867	CPEN208	2026-08-14	Enrolled
133	224018189	CPEN208	2026-08-14	Enrolled
134	22407018	CPEN208	2026-08-14	Enrolled
135	22376708	CPEN208	2026-08-14	Enrolled
136	22377537	CPEN208	2026-08-14	Enrolled
137	22400543	CPEN208	2026-08-14	Enrolled
138	22402666	CPEN208	2026-08-14	Enrolled
139	22416112	CPEN208	2026-08-14	Enrolled
140	22395074	CPEN208	2026-08-14	Enrolled
141	22301848	CPEN204	2026-08-14	Enrolled
142	22268986	CPEN204	2026-08-14	Enrolled
143	22315830	CPEN204	2026-08-14	Enrolled
144	22312110	CPEN204	2026-08-14	Enrolled
145	22300896	CPEN204	2026-08-14	Enrolled
146	22303421	CPEN204	2026-08-14	Enrolled
147	22299189	CPEN204	2026-08-14	Enrolled
148	22302628	CPEN204	2026-08-14	Enrolled
149	22325819	CPEN204	2026-08-14	Enrolled
150	22306910	CPEN204	2026-08-14	Enrolled
151	22263126	CPEN204	2026-08-14	Enrolled
152	22263922	CPEN204	2026-08-14	Enrolled
153	22304260	CPEN204	2026-08-14	Enrolled
154	22304013	CPEN204	2026-08-14	Enrolled
155	22302188	CPEN204	2026-08-14	Enrolled
156	22299949	CPEN204	2026-08-14	Enrolled
157	22328334	CPEN204	2026-08-14	Enrolled
158	22321110	CPEN204	2026-08-14	Enrolled
159	22306021	CPEN204	2026-08-14	Enrolled
160	22271867	CPEN204	2026-08-14	Enrolled
161	22301848	CPEN206	2026-08-14	Enrolled
162	22268986	CPEN206	2026-08-14	Enrolled
163	22315830	CPEN206	2026-08-14	Enrolled
164	22312110	CPEN206	2026-08-14	Enrolled
165	22300896	CPEN206	2026-08-14	Enrolled
166	22303421	CPEN206	2026-08-14	Enrolled
167	22299189	CPEN206	2026-08-14	Enrolled
168	22302628	CPEN206	2026-08-14	Enrolled
169	22325819	CPEN206	2026-08-14	Enrolled
170	22306910	CPEN206	2026-08-14	Enrolled
171	22263126	CPEN206	2026-08-14	Enrolled
172	22263922	CPEN206	2026-08-14	Enrolled
173	22304260	CPEN206	2026-08-14	Enrolled
174	22304013	CPEN206	2026-08-14	Enrolled
175	22302188	CPEN206	2026-08-14	Enrolled
176	22299949	CPEN206	2026-08-14	Enrolled
177	22328334	CPEN206	2026-08-14	Enrolled
178	22321110	CPEN206	2026-08-14	Enrolled
179	22306021	CPEN206	2026-08-14	Enrolled
180	22271867	CPEN206	2026-08-14	Enrolled
\.


--
-- Data for Name: course_lecturers; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.course_lecturers (assignment_id, course_id, lecturer_id, assigned_on) FROM stdin;
1	CPEN208	1	2026-08-14
2	CPEN204	2	2026-08-14
3	CPEN206	3	2026-08-14
4	STAT212	4	2026-08-14
5	MATH222	1	2026-08-14
6	EEEN206	2	2026-08-14
\.


--
-- Data for Name: course_tas; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.course_tas (assignment_id, course_id, ta_id, assigned_on) FROM stdin;
1	CPEN208	1	2026-08-14
2	CPEN208	2	2026-08-14
3	CPEN204	3	2026-08-14
4	CPEN206	4	2026-08-14
5	STAT212	5	2026-08-14
6	MATH222	6	2026-08-14
7	EEEN206	7	2026-08-14
8	CPEN204	8	2026-08-14
9	CPEN206	9	2026-08-14
10	STAT212	10	2026-08-14
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.courses (course_id, course_name, credit_hours, semester, academic_year) FROM stdin;
CPEN208	Introduction to Software Engineering	3	First Semester	2025/2026
CPEN204	Data Structures and Algorithms	3	First Semester	2025/2026
CPEN206	Computer Architecture	3	First Semester	2025/2026
STAT212	Statistics for Engineers	3	First Semester	2025/2026
MATH222	Linear Algebra	3	First Semester	2025/2026
EEEN206	Circuit Theory	3	First Semester	2025/2026
\.


--
-- Data for Name: fee_invoices; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.fee_invoices (invoice_id, student_id, academic_year, semester, amount_due, due_date) FROM stdin;
1	22384451	2025/2026	First Semester	5000.00	2025-11-30
2	22357814	2025/2026	First Semester	5000.00	2025-11-30
3	22375367	2025/2026	First Semester	5000.00	2025-11-30
4	22397756	2025/2026	First Semester	5000.00	2025-11-30
5	22369321	2025/2026	First Semester	5000.00	2025-11-30
6	22301848	2025/2026	First Semester	5000.00	2025-11-30
7	22339520	2025/2026	First Semester	5000.00	2025-11-30
8	22333597	2025/2026	First Semester	5000.00	2025-11-30
9	22268986	2025/2026	First Semester	5000.00	2025-11-30
10	22381577	2025/2026	First Semester	5000.00	2025-11-30
11	22315830	2025/2026	First Semester	5000.00	2025-11-30
12	22388189	2025/2026	First Semester	5000.00	2025-11-30
13	22393520	2025/2026	First Semester	5000.00	2025-11-30
14	22312110	2025/2026	First Semester	5000.00	2025-11-30
15	22300896	2025/2026	First Semester	5000.00	2025-11-30
16	22397491	2025/2026	First Semester	5000.00	2025-11-30
17	22387715	2025/2026	First Semester	5000.00	2025-11-30
18	22382302	2025/2026	First Semester	5000.00	2025-11-30
19	22379061	2025/2026	First Semester	5000.00	2025-11-30
20	22368809	2025/2026	First Semester	5000.00	2025-11-30
21	22370498	2025/2026	First Semester	5000.00	2025-11-30
22	22382425	2025/2026	First Semester	5000.00	2025-11-30
23	22396551	2025/2026	First Semester	5000.00	2025-11-30
24	22398562	2025/2026	First Semester	5000.00	2025-11-30
25	22398596	2025/2026	First Semester	5000.00	2025-11-30
26	22385323	2025/2026	First Semester	5000.00	2025-11-30
27	22303421	2025/2026	First Semester	5000.00	2025-11-30
28	22407033	2025/2026	First Semester	5000.00	2025-11-30
29	22299189	2025/2026	First Semester	5000.00	2025-11-30
30	22407837	2025/2026	First Semester	5000.00	2025-11-30
31	22412615	2025/2026	First Semester	5000.00	2025-11-30
32	22411009	2025/2026	First Semester	5000.00	2025-11-30
33	22382547	2025/2026	First Semester	5000.00	2025-11-30
34	22373317	2025/2026	First Semester	5000.00	2025-11-30
35	22339058	2025/2026	First Semester	5000.00	2025-11-30
36	22302628	2025/2026	First Semester	5000.00	2025-11-30
37	22396566	2025/2026	First Semester	5000.00	2025-11-30
38	22325819	2025/2026	First Semester	5000.00	2025-11-30
39	22344703	2025/2026	First Semester	5000.00	2025-11-30
40	22306910	2025/2026	First Semester	5000.00	2025-11-30
41	22385472	2025/2026	First Semester	5000.00	2025-11-30
42	22399214	2025/2026	First Semester	5000.00	2025-11-30
43	22263126	2025/2026	First Semester	5000.00	2025-11-30
44	22373463	2025/2026	First Semester	5000.00	2025-11-30
45	22381702	2025/2026	First Semester	5000.00	2025-11-30
46	22387846	2025/2026	First Semester	5000.00	2025-11-30
47	22263922	2025/2026	First Semester	5000.00	2025-11-30
48	22401641	2025/2026	First Semester	5000.00	2025-11-30
49	22403781	2025/2026	First Semester	5000.00	2025-11-30
50	22304260	2025/2026	First Semester	5000.00	2025-11-30
51	22304013	2025/2026	First Semester	5000.00	2025-11-30
52	22302188	2025/2026	First Semester	5000.00	2025-11-30
53	22299949	2025/2026	First Semester	5000.00	2025-11-30
54	22415339	2025/2026	First Semester	5000.00	2025-11-30
55	22328334	2025/2026	First Semester	5000.00	2025-11-30
56	22412982	2025/2026	First Semester	5000.00	2025-11-30
57	22321110	2025/2026	First Semester	5000.00	2025-11-30
58	22306021	2025/2026	First Semester	5000.00	2025-11-30
59	22385391	2025/2026	First Semester	5000.00	2025-11-30
60	22394866	2025/2026	First Semester	5000.00	2025-11-30
61	22382601	2025/2026	First Semester	5000.00	2025-11-30
62	22271867	2025/2026	First Semester	5000.00	2025-11-30
63	224018189	2025/2026	First Semester	5000.00	2025-11-30
64	22407018	2025/2026	First Semester	5000.00	2025-11-30
65	22376708	2025/2026	First Semester	5000.00	2025-11-30
66	22377537	2025/2026	First Semester	5000.00	2025-11-30
67	22400543	2025/2026	First Semester	5000.00	2025-11-30
68	22402666	2025/2026	First Semester	5000.00	2025-11-30
69	22416112	2025/2026	First Semester	5000.00	2025-11-30
70	22395074	2025/2026	First Semester	5000.00	2025-11-30
\.


--
-- Data for Name: fee_payments; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.fee_payments (payment_id, student_id, invoice_id, amount_paid, payment_date, reference) FROM stdin;
1	22263126	43	3500.00	2025-10-15	CPEN208-22263126
2	22263922	47	3500.00	2025-10-15	CPEN208-22263922
3	22268986	9	3500.00	2025-10-15	CPEN208-22268986
4	22271867	62	3500.00	2025-10-15	CPEN208-22271867
5	22299189	29	3500.00	2025-10-15	CPEN208-22299189
6	22299949	53	3500.00	2025-10-15	CPEN208-22299949
7	22300896	15	3500.00	2025-10-15	CPEN208-22300896
8	22301848	6	3500.00	2025-10-15	CPEN208-22301848
9	22302188	52	3500.00	2025-10-15	CPEN208-22302188
10	22302628	36	3500.00	2025-10-15	CPEN208-22302628
11	22303421	27	3500.00	2025-10-15	CPEN208-22303421
12	22304013	51	3500.00	2025-10-15	CPEN208-22304013
13	22304260	50	3500.00	2025-10-15	CPEN208-22304260
14	22306021	58	3500.00	2025-10-15	CPEN208-22306021
15	22306910	40	3500.00	2025-10-15	CPEN208-22306910
16	22312110	14	3500.00	2025-10-15	CPEN208-22312110
17	22315830	11	3500.00	2025-10-15	CPEN208-22315830
18	22321110	57	3500.00	2025-10-15	CPEN208-22321110
19	22325819	38	3500.00	2025-10-15	CPEN208-22325819
20	22328334	55	3500.00	2025-10-15	CPEN208-22328334
21	22333597	8	5000.00	2025-10-15	CPEN208-22333597
22	22339058	35	5000.00	2025-10-15	CPEN208-22339058
23	22339520	7	5000.00	2025-10-15	CPEN208-22339520
24	22344703	39	5000.00	2025-10-15	CPEN208-22344703
25	22357814	2	5000.00	2025-10-15	CPEN208-22357814
26	22368809	20	5000.00	2025-10-15	CPEN208-22368809
27	22369321	5	5000.00	2025-10-15	CPEN208-22369321
28	22370498	21	5000.00	2025-10-15	CPEN208-22370498
29	22373317	34	5000.00	2025-10-15	CPEN208-22373317
30	22373463	44	5000.00	2025-10-15	CPEN208-22373463
31	22375367	3	5000.00	2025-10-15	CPEN208-22375367
32	22376708	65	5000.00	2025-10-15	CPEN208-22376708
33	22377537	66	5000.00	2025-10-15	CPEN208-22377537
34	22379061	19	5000.00	2025-10-15	CPEN208-22379061
35	22381577	10	5000.00	2025-10-15	CPEN208-22381577
36	22381702	45	5000.00	2025-10-15	CPEN208-22381702
37	22382302	18	5000.00	2025-10-15	CPEN208-22382302
38	22382425	22	5000.00	2025-10-15	CPEN208-22382425
39	22382547	33	5000.00	2025-10-15	CPEN208-22382547
40	22382601	61	5000.00	2025-10-15	CPEN208-22382601
41	22384451	1	2000.00	2025-10-15	CPEN208-22384451
42	22385323	26	2000.00	2025-10-15	CPEN208-22385323
43	22385391	59	2000.00	2025-10-15	CPEN208-22385391
44	22385472	41	2000.00	2025-10-15	CPEN208-22385472
45	22387715	17	2000.00	2025-10-15	CPEN208-22387715
46	22387846	46	2000.00	2025-10-15	CPEN208-22387846
47	22388189	12	2000.00	2025-10-15	CPEN208-22388189
48	22393520	13	2000.00	2025-10-15	CPEN208-22393520
49	22394866	60	2000.00	2025-10-15	CPEN208-22394866
50	22395074	70	2000.00	2025-10-15	CPEN208-22395074
51	22396551	23	2000.00	2025-10-15	CPEN208-22396551
52	22396566	37	2000.00	2025-10-15	CPEN208-22396566
53	22397491	16	2000.00	2025-10-15	CPEN208-22397491
54	22397756	4	2000.00	2025-10-15	CPEN208-22397756
55	22398562	24	2000.00	2025-10-15	CPEN208-22398562
56	22398596	25	2000.00	2025-10-15	CPEN208-22398596
57	22399214	42	2000.00	2025-10-15	CPEN208-22399214
58	22400543	67	2000.00	2025-10-15	CPEN208-22400543
59	22401641	48	2000.00	2025-10-15	CPEN208-22401641
60	224018189	63	2000.00	2025-10-15	CPEN208-224018189
61	22402666	68	2000.00	2025-10-15	CPEN208-22402666
62	22403781	49	2000.00	2025-10-15	CPEN208-22403781
63	22407018	64	2000.00	2025-10-15	CPEN208-22407018
64	22407033	28	2000.00	2025-10-15	CPEN208-22407033
65	22407837	30	2000.00	2025-10-15	CPEN208-22407837
66	22411009	32	2000.00	2025-10-15	CPEN208-22411009
67	22412615	31	2000.00	2025-10-15	CPEN208-22412615
68	22412982	56	2000.00	2025-10-15	CPEN208-22412982
69	22415339	54	2000.00	2025-10-15	CPEN208-22415339
70	22416112	69	2000.00	2025-10-15	CPEN208-22416112
\.


--
-- Data for Name: lecturers; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.lecturers (lecturer_id, full_name, email, department) FROM stdin;
1	Dr. Kwame Mensah	kwame.mensah@ug.edu.gh	Computer Engineering
2	Dr. Ama Owusu	ama.owusu@ug.edu.gh	Computer Engineering
3	Dr. Kofi Boateng	kofi.boateng@ug.edu.gh	Computer Engineering
4	Dr. Efua Asante	efua.asante@ug.edu.gh	Computer Engineering
\.


--
-- Data for Name: students; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.students (student_id, full_name, email, department, account_status) FROM stdin;
22384451	Abu Neaquittae Golda	22384451@st.ug.edu.gh	Computer Engineering	Active
22357814	Adzasa Stephen Yaw	22357814@st.ug.edu.gh	Computer Engineering	Active
22375367	Afia Beaa Osei-Safo	22375367@st.ug.edu.gh	Computer Engineering	Active
22397756	Agbemavi Ryan	22397756@st.ug.edu.gh	Computer Engineering	Active
22369321	Agormeda Nathaniel Tetteh	22369321@st.ug.edu.gh	Computer Engineering	Active
22301848	Ahmad Mohammed Sahih Kayelgu	22301848@st.ug.edu.gh	Computer Engineering	Active
22339520	Amprofi Yaa Obeng	22339520@st.ug.edu.gh	Computer Engineering	Active
22333597	Asante Esme Lilian	22333597@st.ug.edu.gh	Computer Engineering	Active
22268986	Asante Gabriel Kwaku	22268986@st.ug.edu.gh	Computer Engineering	Active
22381577	Botchway Daniel	22381577@st.ug.edu.gh	Computer Engineering	Active
22315830	Brian Assibey-Yeboah	22315830@st.ug.edu.gh	Computer Engineering	Active
22388189	Caleb Mensah	22388189@st.ug.edu.gh	Computer Engineering	Active
22393520	Cyril Desmond Ofori	22393520@st.ug.edu.gh	Computer Engineering	Active
22312110	David Kwame Odoi-Anim	22312110@st.ug.edu.gh	Computer Engineering	Active
22300896	Doe Collins Kweku	22300896@st.ug.edu.gh	Computer Engineering	Active
22397491	Douglas Kwaw Adjei	22397491@st.ug.edu.gh	Computer Engineering	Active
22387715	Dzidzor Apu Apawudza	22387715@st.ug.edu.gh	Computer Engineering	Active
22382302	Edward Kakra Ankrah	22382302@st.ug.edu.gh	Computer Engineering	Active
22379061	Emmanuel Akotuah Osae	22379061@st.ug.edu.gh	Computer Engineering	Active
22368809	Emmanuel Dery	22368809@st.ug.edu.gh	Computer Engineering	Active
22370498	Ethan Edric Kweku Nartey	22370498@st.ug.edu.gh	Computer Engineering	Active
22382425	Gilbert Akwasi Sarkodie Yeboah	22382425@st.ug.edu.gh	Computer Engineering	Active
22396551	Jerrold Xornam Kyekye	22396551@st.ug.edu.gh	Computer Engineering	Active
22398562	Joseph Amankwah	22398562@st.ug.edu.gh	Computer Engineering	Active
22398596	Joshua Appiah	22398596@st.ug.edu.gh	Computer Engineering	Active
22385323	Jude Gyampoh Addo	22385323@st.ug.edu.gh	Computer Engineering	Active
22303421	Kemausuor Winambe Tetteh-Kumah	22303421@st.ug.edu.gh	Computer Engineering	Active
22407033	Kenzi Segbefia	22407033@st.ug.edu.gh	Computer Engineering	Active
22299189	Kessey Ntiako David	22299189@st.ug.edu.gh	Computer Engineering	Active
22407837	Kingsley Caldicock Quartey	22407837@st.ug.edu.gh	Computer Engineering	Active
22412615	Kofi Boateng Oware-Tano	22412615@st.ug.edu.gh	Computer Engineering	Active
22411009	Kwaku Aninkorah Barimah	22411009@st.ug.edu.gh	Computer Engineering	Active
22382547	Kwame Ayeh Obeng	22382547@st.ug.edu.gh	Computer Engineering	Active
22373317	Kwamena Kesse Quaicoe	22373317@st.ug.edu.gh	Computer Engineering	Active
22339058	Maame Abena Amihere Ahu	22339058@st.ug.edu.gh	Computer Engineering	Active
22302628	Maame Araba Grant-Aidoo	22302628@st.ug.edu.gh	Computer Engineering	Active
22396566	Manford Kelvin Oppong	22396566@st.ug.edu.gh	Computer Engineering	Active
22325819	Nana Adwoa Dansowaah Odoom	22325819@st.ug.edu.gh	Computer Engineering	Active
22344703	Nana Anokye	22344703@st.ug.edu.gh	Computer Engineering	Active
22306910	Newlove Yeboaah Kwarfo	22306910@st.ug.edu.gh	Computer Engineering	Active
22385472	Obeng Ernest Antwi	22385472@st.ug.edu.gh	Computer Engineering	Active
22399214	Obeng Ruth	22399214@st.ug.edu.gh	Computer Engineering	Active
22263126	Owusu Koranteng Yaw Poku	22263126@st.ug.edu.gh	Computer Engineering	Active
22373463	Owusu Nana Boadiwaa	22373463@st.ug.edu.gh	Computer Engineering	Active
22381702	Paula Akosua Asiedua Frimpong	22381702@st.ug.edu.gh	Computer Engineering	Active
22387846	Quaicoo Emile	22387846@st.ug.edu.gh	Computer Engineering	Active
22263922	Romel Alvin Nii Lartey Lartey	22263922@st.ug.edu.gh	Computer Engineering	Active
22401641	Sandra Naa Adaku Mettle	22401641@st.ug.edu.gh	Computer Engineering	Active
22403781	Sekyere Kofi Bempong	22403781@st.ug.edu.gh	Computer Engineering	Active
22304260	Tetteh Christian Edward Nii Mantey	22304260@st.ug.edu.gh	Computer Engineering	Active
22304013	Tietaah Sonnu	22304013@st.ug.edu.gh	Computer Engineering	Active
22302188	Van Jerry Quansah	22302188@st.ug.edu.gh	Computer Engineering	Active
22299949	William Enchill	22299949@st.ug.edu.gh	Computer Engineering	Active
22415339	Kelvin Kwesi Saah	22415339@st.ug.edu.gh	Education	Active
22328334	Etsey Hannah Seyram	22328334@st.ug.edu.gh	Education	Active
22412982	Adu Mini	22412982@st.ug.edu.gh	Education	Active
22321110	Gideon Nana Osei Amofa	22321110@st.ug.edu.gh	Education	Active
22306021	Paul Badu Amponsah	22306021@st.ug.edu.gh	Education	Active
22385391	Najiib Abdul-Majeed Stephen	22385391@st.ug.edu.gh	Education	Active
22394866	Joshua Kwame Asirifi	22394866@st.ug.edu.gh	Education	Active
22382601	Eklou Juliet	22382601@st.ug.edu.gh	Education	Active
22271867	De-Andra Rebecca Ayebo	22271867@st.ug.edu.gh	Education	Active
224018189	Mas'ud Nasir	224018189@st.ug.edu.gh	Education	Active
22407018	Daniel Dwomoh Frimpong	22407018@st.ug.edu.gh	Education	Active
22376708	Adjei Priscilla	22376708@st.ug.edu.gh	Education	Active
22377537	Reuben Adomako	22377537@st.ug.edu.gh	Education	Active
22400543	Ocansey Frederick	22400543@st.ug.edu.gh	Computer Engineering	Active
22402666	Dogbatse Darlington	22402666@st.ug.edu.gh	Education	Active
22416112	Troy Thomas	22416112@st.ug.edu.gh	Education	Active
22395074	Lydia Tiwaah	22395074@st.ug.edu.gh	Education	Active
87654321	Phoebe Bridgers	87654321@st.ug.edu.gh	Computer Engineering	Active
\.


--
-- Data for Name: teaching_assistants; Type: TABLE DATA; Schema: cpen208; Owner: postgres
--

COPY cpen208.teaching_assistants (ta_id, student_id, role) FROM stdin;
1	22384451	TA
2	22357814	TA
3	22375367	TA
4	22397756	TA
5	22369321	TA
6	22301848	TA
7	22339520	TA
8	22333597	TA
9	22268986	TA
10	22381577	TA
11	22315830	TA
12	22388189	TA
\.


--
-- Name: app_users_user_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.app_users_user_id_seq', 2, true);


--
-- Name: course_enrollments_enrollment_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.course_enrollments_enrollment_id_seq', 181, true);


--
-- Name: course_lecturers_assignment_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.course_lecturers_assignment_id_seq', 6, true);


--
-- Name: course_tas_assignment_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.course_tas_assignment_id_seq', 10, true);


--
-- Name: fee_invoices_invoice_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.fee_invoices_invoice_id_seq', 70, true);


--
-- Name: fee_payments_payment_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.fee_payments_payment_id_seq', 73, true);


--
-- Name: lecturers_lecturer_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.lecturers_lecturer_id_seq', 4, true);


--
-- Name: teaching_assistants_ta_id_seq; Type: SEQUENCE SET; Schema: cpen208; Owner: postgres
--

SELECT pg_catalog.setval('cpen208.teaching_assistants_ta_id_seq', 12, true);


--
-- Name: app_users app_users_email_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.app_users
    ADD CONSTRAINT app_users_email_key UNIQUE (email);


--
-- Name: app_users app_users_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.app_users
    ADD CONSTRAINT app_users_pkey PRIMARY KEY (user_id);


--
-- Name: course_enrollments course_enrollments_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_enrollments
    ADD CONSTRAINT course_enrollments_pkey PRIMARY KEY (enrollment_id);


--
-- Name: course_enrollments course_enrollments_student_id_course_id_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_enrollments
    ADD CONSTRAINT course_enrollments_student_id_course_id_key UNIQUE (student_id, course_id);


--
-- Name: course_lecturers course_lecturers_course_id_lecturer_id_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_lecturers
    ADD CONSTRAINT course_lecturers_course_id_lecturer_id_key UNIQUE (course_id, lecturer_id);


--
-- Name: course_lecturers course_lecturers_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_lecturers
    ADD CONSTRAINT course_lecturers_pkey PRIMARY KEY (assignment_id);


--
-- Name: course_tas course_tas_course_id_ta_id_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_tas
    ADD CONSTRAINT course_tas_course_id_ta_id_key UNIQUE (course_id, ta_id);


--
-- Name: course_tas course_tas_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_tas
    ADD CONSTRAINT course_tas_pkey PRIMARY KEY (assignment_id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (course_id);


--
-- Name: fee_invoices fee_invoices_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_invoices
    ADD CONSTRAINT fee_invoices_pkey PRIMARY KEY (invoice_id);


--
-- Name: fee_invoices fee_invoices_student_id_academic_year_semester_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_invoices
    ADD CONSTRAINT fee_invoices_student_id_academic_year_semester_key UNIQUE (student_id, academic_year, semester);


--
-- Name: fee_payments fee_payments_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_payments
    ADD CONSTRAINT fee_payments_pkey PRIMARY KEY (payment_id);


--
-- Name: fee_payments fee_payments_reference_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_payments
    ADD CONSTRAINT fee_payments_reference_key UNIQUE (reference);


--
-- Name: lecturers lecturers_email_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.lecturers
    ADD CONSTRAINT lecturers_email_key UNIQUE (email);


--
-- Name: lecturers lecturers_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.lecturers
    ADD CONSTRAINT lecturers_pkey PRIMARY KEY (lecturer_id);


--
-- Name: students students_email_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.students
    ADD CONSTRAINT students_email_key UNIQUE (email);


--
-- Name: students students_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.students
    ADD CONSTRAINT students_pkey PRIMARY KEY (student_id);


--
-- Name: teaching_assistants teaching_assistants_pkey; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.teaching_assistants
    ADD CONSTRAINT teaching_assistants_pkey PRIMARY KEY (ta_id);


--
-- Name: teaching_assistants teaching_assistants_student_id_key; Type: CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.teaching_assistants
    ADD CONSTRAINT teaching_assistants_student_id_key UNIQUE (student_id);


--
-- Name: idx_enrollments_student; Type: INDEX; Schema: cpen208; Owner: postgres
--

CREATE INDEX idx_enrollments_student ON cpen208.course_enrollments USING btree (student_id);


--
-- Name: idx_invoices_student; Type: INDEX; Schema: cpen208; Owner: postgres
--

CREATE INDEX idx_invoices_student ON cpen208.fee_invoices USING btree (student_id);


--
-- Name: idx_payments_student; Type: INDEX; Schema: cpen208; Owner: postgres
--

CREATE INDEX idx_payments_student ON cpen208.fee_payments USING btree (student_id);


--
-- Name: course_enrollments course_enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_enrollments
    ADD CONSTRAINT course_enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES cpen208.courses(course_id) ON DELETE CASCADE;


--
-- Name: course_enrollments course_enrollments_student_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_enrollments
    ADD CONSTRAINT course_enrollments_student_id_fkey FOREIGN KEY (student_id) REFERENCES cpen208.students(student_id) ON DELETE CASCADE;


--
-- Name: course_lecturers course_lecturers_course_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_lecturers
    ADD CONSTRAINT course_lecturers_course_id_fkey FOREIGN KEY (course_id) REFERENCES cpen208.courses(course_id) ON DELETE CASCADE;


--
-- Name: course_lecturers course_lecturers_lecturer_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_lecturers
    ADD CONSTRAINT course_lecturers_lecturer_id_fkey FOREIGN KEY (lecturer_id) REFERENCES cpen208.lecturers(lecturer_id) ON DELETE CASCADE;


--
-- Name: course_tas course_tas_course_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_tas
    ADD CONSTRAINT course_tas_course_id_fkey FOREIGN KEY (course_id) REFERENCES cpen208.courses(course_id) ON DELETE CASCADE;


--
-- Name: course_tas course_tas_ta_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.course_tas
    ADD CONSTRAINT course_tas_ta_id_fkey FOREIGN KEY (ta_id) REFERENCES cpen208.teaching_assistants(ta_id) ON DELETE CASCADE;


--
-- Name: fee_invoices fee_invoices_student_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_invoices
    ADD CONSTRAINT fee_invoices_student_id_fkey FOREIGN KEY (student_id) REFERENCES cpen208.students(student_id) ON DELETE CASCADE;


--
-- Name: fee_payments fee_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_payments
    ADD CONSTRAINT fee_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES cpen208.fee_invoices(invoice_id) ON DELETE CASCADE;


--
-- Name: fee_payments fee_payments_student_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.fee_payments
    ADD CONSTRAINT fee_payments_student_id_fkey FOREIGN KEY (student_id) REFERENCES cpen208.students(student_id) ON DELETE CASCADE;


--
-- Name: teaching_assistants teaching_assistants_student_id_fkey; Type: FK CONSTRAINT; Schema: cpen208; Owner: postgres
--

ALTER TABLE ONLY cpen208.teaching_assistants
    ADD CONSTRAINT teaching_assistants_student_id_fkey FOREIGN KEY (student_id) REFERENCES cpen208.students(student_id);


--
-- PostgreSQL database dump complete
--

\unrestrict jMNGPAdnC6rXRnrvYsXI1ZWXlgcqVOB0ZwEF4JkyKhaRtAshlIMI9aw0g2kEUD2

