-- CPEN 208 Project 1 + Project 2
-- PostgreSQL
DROP SCHEMA IF EXISTS cpen208 CASCADE;
CREATE SCHEMA cpen208;
SET search_path TO cpen208, public;

CREATE TABLE students (
  student_id VARCHAR(20) PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  department VARCHAR(120) NOT NULL DEFAULT 'Computer Engineering',
  account_status VARCHAR(20) NOT NULL DEFAULT 'Active'
    CHECK (account_status IN ('Active','Inactive'))
);

CREATE TABLE lecturers (
  lecturer_id SERIAL PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  department VARCHAR(120) NOT NULL DEFAULT 'Computer Engineering'
);

CREATE TABLE teaching_assistants (
  ta_id SERIAL PRIMARY KEY,
  student_id VARCHAR(20) UNIQUE NOT NULL REFERENCES students(student_id),
  role VARCHAR(30) NOT NULL DEFAULT 'TA'
);

CREATE TABLE courses (
  course_id VARCHAR(20) PRIMARY KEY,
  course_name VARCHAR(150) NOT NULL,
  credit_hours INT NOT NULL CHECK (credit_hours > 0),
  semester VARCHAR(30) NOT NULL,
  academic_year VARCHAR(20) NOT NULL
);

CREATE TABLE course_enrollments (
  enrollment_id BIGSERIAL PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
  course_id VARCHAR(20) NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  enrolled_on DATE NOT NULL DEFAULT CURRENT_DATE,
  status VARCHAR(20) NOT NULL DEFAULT 'Enrolled'
    CHECK (status IN ('Enrolled','Dropped','Completed')),
  UNIQUE(student_id, course_id)
);

CREATE TABLE course_lecturers (
  assignment_id BIGSERIAL PRIMARY KEY,
  course_id VARCHAR(20) NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  lecturer_id INT NOT NULL REFERENCES lecturers(lecturer_id) ON DELETE CASCADE,
  assigned_on DATE NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE(course_id, lecturer_id)
);

CREATE TABLE course_tas (
  assignment_id BIGSERIAL PRIMARY KEY,
  course_id VARCHAR(20) NOT NULL REFERENCES courses(course_id) ON DELETE CASCADE,
  ta_id INT NOT NULL REFERENCES teaching_assistants(ta_id) ON DELETE CASCADE,
  assigned_on DATE NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE(course_id, ta_id)
);

CREATE TABLE fee_invoices (
  invoice_id BIGSERIAL PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
  academic_year VARCHAR(20) NOT NULL,
  semester VARCHAR(30) NOT NULL,
  amount_due NUMERIC(12,2) NOT NULL CHECK (amount_due >= 0),
  due_date DATE NOT NULL,
  UNIQUE(student_id, academic_year, semester)
);

CREATE TABLE fee_payments (
  payment_id BIGSERIAL PRIMARY KEY,
  student_id VARCHAR(20) NOT NULL REFERENCES students(student_id) ON DELETE CASCADE,
  invoice_id BIGINT NOT NULL REFERENCES fee_invoices(invoice_id) ON DELETE CASCADE,
  amount_paid NUMERIC(12,2) NOT NULL CHECK (amount_paid > 0),
  payment_date DATE NOT NULL DEFAULT CURRENT_DATE,
  reference VARCHAR(60) UNIQUE NOT NULL
);

CREATE INDEX idx_enrollments_student ON course_enrollments(student_id);
CREATE INDEX idx_payments_student ON fee_payments(student_id);
CREATE INDEX idx_invoices_student ON fee_invoices(student_id);

CREATE OR REPLACE FUNCTION get_outstanding_fees()
RETURNS JSONB
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN COALESCE((
    SELECT jsonb_agg(
      jsonb_build_object(
        'student_id', x.student_id,
        'student_name', x.full_name,
        'amount_due', x.amount_due,
        'amount_paid', x.amount_paid,
        'outstanding', GREATEST(x.amount_due - x.amount_paid, 0)
      ) ORDER BY x.full_name
    )
    FROM (
      SELECT s.student_id, s.full_name,
             COALESCE(SUM(fi.amount_due),0) AS amount_due,
             COALESCE(SUM(fp.paid),0) AS amount_paid
      FROM students s
      LEFT JOIN fee_invoices fi ON fi.student_id = s.student_id
      LEFT JOIN (
        SELECT invoice_id, SUM(amount_paid) AS paid
        FROM fee_payments GROUP BY invoice_id
      ) fp ON fp.invoice_id = fi.invoice_id
      GROUP BY s.student_id, s.full_name
    ) x
  ), '[]'::jsonb);
END;
$$;

CREATE OR REPLACE VIEW student_fee_summary AS
SELECT s.student_id, s.full_name,
       COALESCE(SUM(fi.amount_due),0) AS total_due,
       COALESCE(SUM(p.paid),0) AS total_paid,
       GREATEST(COALESCE(SUM(fi.amount_due),0)-COALESCE(SUM(p.paid),0),0) AS outstanding
FROM students s
LEFT JOIN fee_invoices fi ON fi.student_id=s.student_id
LEFT JOIN (
  SELECT invoice_id, SUM(amount_paid) paid FROM fee_payments GROUP BY invoice_id
) p ON p.invoice_id=fi.invoice_id
GROUP BY s.student_id,s.full_name;

CREATE TABLE app_users (
  user_id BIGSERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
