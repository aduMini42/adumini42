import { Pool } from "pg";

const globalForDb = globalThis as unknown as { pool?: Pool };

export const pool =
  globalForDb.pool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    options: '-c search_path=cpen208,public',
    ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
  });

if (process.env.NODE_ENV !== "production") globalForDb.pool = pool;
