import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CPEN 208 Student Management",
  description: "Combined CPEN 208 Project 1 and Project 2"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
