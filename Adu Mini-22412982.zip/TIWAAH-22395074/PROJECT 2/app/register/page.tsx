"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  const [error,setError]=useState(""); const router=useRouter();
  async function submit(e:FormEvent){
    e.preventDefault(); setError("");
    const res=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,email,password})});
    const data=await res.json();
    if(!res.ok){setError(data.error||"Registration failed");return;}
    router.push("/dashboard");
  }
  return <main className="hero"><div className="card auth">
    <h1>Create account</h1><p className="muted">Use this account to access the dashboard.</p>
    {error && <div className="error">{error}</div>}
    <form onSubmit={submit}>
      <label>Full name</label><input value={name} onChange={e=>setName(e.target.value)} required />
      <label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
      <label>Password</label><input type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required />
      <div className="actions"><button className="btn">Register</button><a className="btn secondary" href="/login">Back to login</a></div>
    </form>
  </div></main>;
}
