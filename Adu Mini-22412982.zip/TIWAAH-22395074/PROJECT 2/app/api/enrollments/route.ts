import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";

export async function GET() {
  const { rows } = await pool.query(`
    SELECT ce.enrollment_id,ce.student_id,s.full_name,ce.course_id,c.course_name,ce.status,ce.enrolled_on
    FROM cpen208.course_enrollments ce
    JOIN cpen208.students s ON s.student_id=ce.student_id
    JOIN cpen208.courses c ON c.course_id=ce.course_id
    ORDER BY s.full_name,c.course_id`);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const {student_id, course_id} = await req.json();
    if (!student_id || !course_id)
      return NextResponse.json({error:"student_id and course_id are required."},{status:400});
    const {rows}=await pool.query(
      `INSERT INTO cpen208.course_enrollments(student_id,course_id)
       VALUES($1,$2) RETURNING *`,[student_id,course_id]);
    return NextResponse.json(rows[0],{status:201});
  } catch {
    return NextResponse.json({error:"Enrollment failed. Check the student, course, or duplicate enrollment."},{status:409});
  }
}

export async function PATCH(req: Request) {
  try {
    const {enrollment_id, status} = await req.json();
    if (!enrollment_id || !status)
      return NextResponse.json({error:"enrollment_id and status are required."},{status:400});
    if (!["Enrolled","Dropped","Completed"].includes(status))
      return NextResponse.json({error:"status must be Enrolled, Dropped, or Completed."},{status:400});
    const {rows}=await pool.query(
      `UPDATE cpen208.course_enrollments SET status=$2 WHERE enrollment_id=$1 RETURNING *`,
      [enrollment_id, status]);
    if (!rows.length) return NextResponse.json({error:"Enrollment not found."},{status:404});
    return NextResponse.json(rows[0]);
  } catch {
    return NextResponse.json({error:"Enrollment could not be updated."},{status:409});
  }
}

export async function DELETE(req: Request) {
  try {
    const {enrollment_id} = await req.json();
    if (!enrollment_id) return NextResponse.json({error:"enrollment_id is required."},{status:400});
    const {rowCount}=await pool.query("DELETE FROM cpen208.course_enrollments WHERE enrollment_id=$1",[enrollment_id]);
    if (!rowCount) return NextResponse.json({error:"Enrollment not found."},{status:404});
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:"Enrollment could not be deleted."},{status:409});
  }
}
