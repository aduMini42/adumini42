import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";

export async function GET() {
  const { rows } = await pool.query(
    "SELECT student_id,full_name,email,department,account_status FROM cpen208.students ORDER BY full_name"
  );
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const { student_id, full_name, email } = await req.json();
    if (!student_id || !full_name || !email)
      return NextResponse.json({error:"student_id, full_name and email are required."},{status:400});
    const { rows } = await pool.query(
      `INSERT INTO cpen208.students(student_id,full_name,email)
       VALUES($1,$2,$3) RETURNING *`, [student_id, full_name, email.toLowerCase()]
    );
    return NextResponse.json(rows[0], {status:201});
  } catch {
    return NextResponse.json({error:"Student could not be created. Check the ID/email."},{status:409});
  }
}

export async function DELETE(req: Request) {
  try {
    const { student_id } = await req.json();
    if (!student_id)
      return NextResponse.json({error:"student_id is required."},{status:400});
    const { rowCount } = await pool.query(
      "DELETE FROM cpen208.students WHERE student_id=$1", [student_id]
    );
    if (!rowCount) return NextResponse.json({error:"Student not found."},{status:404});
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:"Student could not be deleted. They may have related enrollments, fees, or a TA record."},{status:409});
  }
}