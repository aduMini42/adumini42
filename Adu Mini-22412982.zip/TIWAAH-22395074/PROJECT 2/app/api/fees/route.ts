import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";

// Maps raw Postgres errors to a clear, specific message instead of one
// generic guess. err.code is the SQLSTATE code Postgres/pg always sets.
function feeErrorMessage(err: any): string {
  console.error("fee_payments error:", err);
  if (err?.code === "23505") return "That reference is already used by another payment.";
  if (err?.code === "23514" && err?.constraint?.includes("amount_paid"))
    return "Amount paid must be greater than 0.";
  if (err?.code === "23503") return "That student_id or invoice_id does not exist.";
  return "Payment could not be saved. Please check your input.";
}

export async function GET(req: Request) {
  const url = new URL(req.url);
  if (url.searchParams.get("view") === "payments") {
    const {rows} = await pool.query(`
      SELECT fp.payment_id, fp.student_id, s.full_name, fp.invoice_id,
             fp.amount_paid, fp.payment_date, fp.reference
      FROM cpen208.fee_payments fp
      JOIN cpen208.students s ON s.student_id=fp.student_id
      ORDER BY fp.payment_date DESC, fp.payment_id DESC`);
    return NextResponse.json(rows);
  }
  const {rows}=await pool.query(`
    SELECT fi.invoice_id, fi.student_id, s.full_name, fi.amount_due,
           COALESCE(SUM(fp.amount_paid),0) AS amount_paid,
           GREATEST(fi.amount_due-COALESCE(SUM(fp.amount_paid),0),0) AS outstanding
    FROM cpen208.fee_invoices fi
    JOIN cpen208.students s ON s.student_id=fi.student_id
    LEFT JOIN cpen208.fee_payments fp ON fp.invoice_id=fi.invoice_id
    GROUP BY fi.invoice_id,s.full_name ORDER BY s.full_name`);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const {student_id, invoice_id, amount_paid, reference} = await req.json();
    if (!student_id || !invoice_id || !amount_paid || !reference)
      return NextResponse.json({error:"student_id, invoice_id, amount_paid and reference are required."},{status:400});
    const {rows}=await pool.query(
      `INSERT INTO cpen208.fee_payments(student_id,invoice_id,amount_paid,reference)
       VALUES($1,$2,$3,$4) RETURNING *`,[student_id,invoice_id,amount_paid,reference]);
    return NextResponse.json(rows[0],{status:201});
  } catch (err) {
    return NextResponse.json({error:feeErrorMessage(err)},{status:409});
  }
}

export async function PATCH(req: Request) {
  try {
    const {payment_id, amount_paid, reference} = await req.json();
    if (!payment_id || (!amount_paid && !reference))
      return NextResponse.json({error:"payment_id and at least one of amount_paid/reference are required."},{status:400});
    const {rows}=await pool.query(
      `UPDATE cpen208.fee_payments
       SET amount_paid=COALESCE($2,amount_paid), reference=COALESCE($3,reference)
       WHERE payment_id=$1 RETURNING *`,
      [payment_id, amount_paid ?? null, reference ?? null]);
    if (!rows.length) return NextResponse.json({error:"Payment not found."},{status:404});
    return NextResponse.json(rows[0]);
  } catch (err) {
    return NextResponse.json({error:feeErrorMessage(err)},{status:409});
  }
}

export async function DELETE(req: Request) {
  try {
    const {payment_id} = await req.json();
    if (!payment_id) return NextResponse.json({error:"payment_id is required."},{status:400});
    const {rowCount}=await pool.query("DELETE FROM cpen208.fee_payments WHERE payment_id=$1",[payment_id]);
    if (!rowCount) return NextResponse.json({error:"Payment not found."},{status:404});
    return NextResponse.json({ok:true});
  } catch (err) {
    return NextResponse.json({error:feeErrorMessage(err)},{status:409});
  }
}