import { NextResponse } from "next/server";
import { pool } from "../../../../lib/db";

export async function GET(){
  const {rows}=await pool.query("SELECT cpen208.get_outstanding_fees() AS data");
  return NextResponse.json(rows[0]?.data ?? []);
}
