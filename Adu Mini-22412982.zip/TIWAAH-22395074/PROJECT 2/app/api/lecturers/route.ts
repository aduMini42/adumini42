import { NextResponse } from "next/server";
import { pool } from "../../../lib/db";

export async function GET() {
  const { rows } = await pool.query(
    "SELECT lecturer_id,full_name,email,department FROM cpen208.lecturers ORDER BY full_name"
  );
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  try {
    const { full_name, email, department } = await req.json();
    if (!full_name || !email)
      return NextResponse.json({error:"full_name and email are required."},{status:400});
    const { rows } = await pool.query(
      `INSERT INTO cpen208.lecturers(full_name,email,department)
       VALUES($1,$2,COALESCE($3,'Computer Engineering')) RETURNING *`,
      [full_name, email.toLowerCase(), department || null]
    );
    return NextResponse.json(rows[0], {status:201});
  } catch {
    return NextResponse.json({error:"Lecturer could not be created. Check the email."},{status:409});
  }
}

export async function DELETE(req: Request) {
  try {
    const { lecturer_id } = await req.json();
    if (!lecturer_id)
      return NextResponse.json({error:"lecturer_id is required."},{status:400});
    const { rowCount } = await pool.query(
      "DELETE FROM cpen208.lecturers WHERE lecturer_id=$1", [lecturer_id]
    );
    if (!rowCount) return NextResponse.json({error:"Lecturer not found."},{status:404});
    return NextResponse.json({ok:true});
  } catch {
    return NextResponse.json({error:"Lecturer could not be deleted."},{status:409});
  }
}
